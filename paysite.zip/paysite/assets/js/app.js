// ---------- تم روشن/تاریک ----------
(function () {
    const saved = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', saved);
    document.addEventListener('DOMContentLoaded', () => {
        const toggle = document.getElementById('theme-toggle');
        if (!toggle) return;
        updateIcon(saved);
        toggle.addEventListener('click', () => {
            const cur = document.documentElement.getAttribute('data-theme');
            const next = cur === 'dark' ? 'light' : 'dark';
            document.documentElement.setAttribute('data-theme', next);
            localStorage.setItem('theme', next);
            updateIcon(next);
        });
        function updateIcon(mode) {
            toggle.textContent = mode === 'dark' ? '☀️' : '🌙';
        }
    });
})();

// ---------- کپی شماره کارت ----------
function copyCardNumber(btn, number) {
    navigator.clipboard.writeText(number.replace(/[^0-9]/g, '')).then(() => {
        const original = btn.textContent;
        btn.textContent = 'کپی شد ✓';
        setTimeout(() => (btn.textContent = original), 1500);
    });
}

// ---------- پیش‌نمایش آپلود رسید ----------
document.addEventListener('DOMContentLoaded', () => {
    const dropzone = document.getElementById('dropzone');
    const input = document.getElementById('receipt-input');
    const preview = document.getElementById('preview-img');
    const fileNameLabel = document.getElementById('file-name-label');

    if (!dropzone || !input) return;

    dropzone.addEventListener('click', () => input.click());

    ['dragover', 'dragenter'].forEach(evt =>
        dropzone.addEventListener(evt, (e) => { e.preventDefault(); dropzone.classList.add('dragover'); })
    );
    ['dragleave', 'drop'].forEach(evt =>
        dropzone.addEventListener(evt, (e) => { e.preventDefault(); dropzone.classList.remove('dragover'); })
    );
    dropzone.addEventListener('drop', (e) => {
        if (e.dataTransfer.files.length) {
            input.files = e.dataTransfer.files;
            handleFile(input.files[0]);
        }
    });
    input.addEventListener('change', () => {
        if (input.files.length) handleFile(input.files[0]);
    });

    function handleFile(file) {
        if (fileNameLabel) fileNameLabel.textContent = file.name;
        if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = (e) => {
                preview.src = e.target.result;
                preview.style.display = 'block';
            };
            reader.readAsDataURL(file);
        } else {
            preview.style.display = 'none';
        }
    }
});

// ---------- جلوگیری از ارسال دوباره فرم ----------
function lockSubmit(form, btn) {
    form.addEventListener('submit', () => {
        btn.disabled = true;
        const spinner = btn.querySelector('.spinner');
        if (spinner) spinner.style.display = 'inline-block';
    });
}

// ---------- فقط عدد در ورودی مبلغ ----------
function digitsOnly(el) {
    el.addEventListener('input', () => {
        el.value = el.value.replace(/[^0-9]/g, '');
    });
}
