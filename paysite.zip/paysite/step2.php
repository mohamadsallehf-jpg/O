<?php
require_once __DIR__ . '/config.php';

if (empty($_SESSION['flow']['amount'])) {
    redirect('index.php');
}

$pageTitle = 'اطلاعات کاربر | ' . get_setting($pdo, 'site_title');
$error = '';
$full_name = $email = $phone = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        $error = 'نشست شما منقضی شده است. لطفاً صفحه را رفرش کنید.';
    } elseif (!rate_limit_check($pdo, 'step2', 8, 60)) {
        $error = 'تعداد درخواست‌های شما زیاد است. کمی بعد دوباره تلاش کنید.';
    } else {
        $full_name = clean_str($_POST['full_name'] ?? '');
        $email = clean_str($_POST['email'] ?? '');
        $phone = clean_str($_POST['phone'] ?? '');

        if (mb_strlen($full_name) < 3) {
            $error = 'نام و نام خانوادگی را کامل وارد کنید.';
        } elseif (!is_valid_email($email)) {
            $error = 'ایمیل وارد شده معتبر نیست.';
        } elseif ($phone !== '' && !preg_match('/^[0-9+\-\s]{7,15}$/', $phone)) {
            $error = 'شماره تماس معتبر نیست.';
        } else {
            $_SESSION['flow']['full_name'] = $full_name;
            $_SESSION['flow']['email'] = $email;
            $_SESSION['flow']['phone'] = $phone;
            redirect('step3.php');
        }
    }
}

require __DIR__ . '/includes/header.php';
?>

<div class="stepper">
    <div class="step-dot done">✓</div><div class="step-line done"></div>
    <div class="step-dot active">۲</div><div class="step-line"></div>
    <div class="step-dot">۳</div>
</div>

<div class="card card-glow">
    <h2 class="text-center mb-2">اطلاعات خود را وارد کنید</h2>
    <p class="hint text-center mb-2">مبلغ انتخابی شما: <b><?= toman($_SESSION['flow']['amount']) ?></b></p>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= h($error) ?></div>
    <?php endif; ?>

    <form method="post" id="info-form">
        <?= csrf_field() ?>
        <div class="form-group">
            <label for="full_name">نام و نام خانوادگی</label>
            <input type="text" id="full_name" name="full_name" value="<?= h($full_name) ?>" required>
        </div>
        <div class="form-group">
            <label for="email">ایمیل (نتیجه به این آدرس ارسال می‌شود)</label>
            <input type="email" id="email" name="email" value="<?= h($email) ?>" required>
        </div>
        <div class="form-group">
            <label for="phone">شماره تماس (اختیاری)</label>
            <input type="tel" id="phone" name="phone" value="<?= h($phone) ?>">
        </div>
        <button type="submit" class="btn btn-primary btn-block" id="submit-btn">
            ادامه <span class="spinner"></span>
        </button>
        <a href="index.php" class="btn btn-outline btn-block mt-2">بازگشت</a>
    </form>
</div>

<script>
    lockSubmit(document.getElementById('info-form'), document.getElementById('submit-btn'));
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>
