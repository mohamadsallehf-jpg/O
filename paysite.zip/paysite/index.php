<?php
require_once __DIR__ . '/config.php';

$pageTitle = 'وارد کردن مبلغ | ' . get_setting($pdo, 'site_title');
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        $error = 'نشست شما منقضی شده است. لطفاً صفحه را رفرش کنید.';
    } elseif (!rate_limit_check($pdo, 'step1', 8, 60)) {
        $error = 'تعداد درخواست‌های شما زیاد است. کمی بعد دوباره تلاش کنید.';
    } else {
        [$ok, $amount, $msg] = is_valid_amount($_POST['amount'] ?? '', $pdo);
        if (!$ok) {
            $error = $msg;
        } else {
            $_SESSION['flow'] = ['amount' => $amount];
            redirect('step2.php');
        }
    }
}

$minAmount = (int) get_setting($pdo, 'min_amount', 10000);
$maxAmount = (int) get_setting($pdo, 'max_amount', 500000000);

require __DIR__ . '/includes/header.php';
?>

<div class="stepper">
    <div class="step-dot active">۱</div><div class="step-line"></div>
    <div class="step-dot">۲</div><div class="step-line"></div>
    <div class="step-dot">۳</div>
</div>

<div class="card card-glow">
    <h2 class="text-center mb-2">مبلغ واریزی خود را وارد کنید</h2>
    <p class="hint text-center mb-2">حداقل <?= toman($minAmount) ?> و حداکثر <?= toman($maxAmount) ?></p>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= h($error) ?></div>
    <?php endif; ?>

    <form method="post" id="amount-form">
        <?= csrf_field() ?>
        <div class="form-group">
            <label for="amount">مبلغ (تومان)</label>
            <input type="text" inputmode="numeric" id="amount" name="amount" placeholder="مثلاً 500000" required autofocus>
        </div>
        <button type="submit" class="btn btn-primary btn-block" id="submit-btn">
            ادامه <span class="spinner"></span>
        </button>
    </form>
</div>

<script>
    digitsOnly(document.getElementById('amount'));
    lockSubmit(document.getElementById('amount-form'), document.getElementById('submit-btn'));
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>
