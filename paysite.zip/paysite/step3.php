<?php
require_once __DIR__ . '/config.php';

if (empty($_SESSION['flow']['amount']) || empty($_SESSION['flow']['email'])) {
    redirect('index.php');
}

$pageTitle = 'پرداخت و آپلود رسید | ' . get_setting($pdo, 'site_title');
$error = '';

$cardNumber = get_setting($pdo, 'card_number');
$cardHolder = get_setting($pdo, 'card_holder');
$bankName = get_setting($pdo, 'bank_name');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        $error = 'نشست شما منقضی شده است. لطفاً صفحه را رفرش کنید.';
    } elseif (!rate_limit_check($pdo, 'step3', 5, 120)) {
        $error = 'تعداد درخواست‌های شما زیاد است. کمی بعد دوباره تلاش کنید.';
    } elseif (empty($_SESSION['captcha_answer']) || clean_str($_POST['captcha'] ?? '') != $_SESSION['captcha_answer']) {
        $error = 'پاسخ سوال امنیتی صحیح نیست.';
    } else {
        [$uploadOk, $filename, $uploadMsg] = handle_receipt_upload($_FILES['receipt'] ?? []);
        if (!$uploadOk) {
            $error = $uploadMsg;
        } else {
            $token = bin2hex(random_bytes(12));
            $stmt = $pdo->prepare("INSERT INTO requests
                (public_token, full_name, email, phone, amount, card_number_shown, receipt_path, receipt_original_name, status, ip_address, user_agent, created_at)
                VALUES (:tok, :fn, :em, :ph, :am, :cn, :rp, :ro, 'pending', :ip, :ua, :ca)");
            $stmt->execute([
                ':tok' => $token,
                ':fn' => $_SESSION['flow']['full_name'],
                ':em' => $_SESSION['flow']['email'],
                ':ph' => $_SESSION['flow']['phone'] ?? '',
                ':am' => $_SESSION['flow']['amount'],
                ':cn' => $cardNumber,
                ':rp' => $filename,
                ':ro' => $_FILES['receipt']['name'] ?? '',
                ':ip' => client_ip(),
                ':ua' => substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255),
                ':ca' => date('c'),
            ]);

            // اطلاع‌رسانی ایمیلی به کاربر (رسید دریافت شد)
            send_email($pdo, $_SESSION['flow']['email'], 'رسید شما دریافت شد',
                "<div style='font-family:Tahoma;direction:rtl'>
                <p>سلام " . h($_SESSION['flow']['full_name']) . "،</p>
                <p>رسید پرداخت شما به مبلغ " . toman($_SESSION['flow']['amount']) . " با موفقیت دریافت شد و در صف بررسی قرار گرفت.</p>
                <p>کد پیگیری شما: <b>$token</b></p>
                </div>");

            // اطلاع‌رسانی به ادمین‌ها
            $admins = $pdo->query("SELECT email FROM admins WHERE email IS NOT NULL AND email != '' AND is_active = 1")->fetchAll();
            foreach ($admins as $a) {
                send_email($pdo, $a['email'], 'رسید جدید برای بررسی',
                    "<div style='font-family:Tahoma;direction:rtl'>
                    <p>یک درخواست پرداخت جدید ثبت شد.</p>
                    <p>مبلغ: " . toman($_SESSION['flow']['amount']) . "</p>
                    <p>کاربر: " . h($_SESSION['flow']['full_name']) . "</p>
                    <p>برای بررسی به پنل مدیریت مراجعه کنید.</p>
                    </div>");
            }

            unset($_SESSION['flow'], $_SESSION['captcha_answer']);
            redirect('thankyou.php?token=' . urlencode($token));
        }
    }
}

// کپچای ریاضی ساده (بدون نیاز به سرویس خارجی)
$a = random_int(1, 9); $b = random_int(1, 9);
$_SESSION['captcha_answer'] = $a + $b;

require __DIR__ . '/includes/header.php';
?>

<div class="stepper">
    <div class="step-dot done">✓</div><div class="step-line done"></div>
    <div class="step-dot done">✓</div><div class="step-line done"></div>
    <div class="step-dot active">۳</div>
</div>

<div class="card-display mb-2">
    <div class="card-meta"><span><?= h($bankName) ?></span><span><?= h($cardHolder) ?></span></div>
    <div class="card-number" id="card-num"><?= h($cardNumber) ?></div>
    <div class="text-center">
        <button type="button" class="copy-btn" onclick="copyCardNumber(this, '<?= h($cardNumber) ?>')">کپی شماره کارت</button>
    </div>
</div>

<div class="card card-glow">
    <h2 class="text-center mb-2">مبلغ <?= toman($_SESSION['flow']['amount']) ?> را واریز و رسید را آپلود کنید</h2>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= h($error) ?></div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" id="upload-form">
        <?= csrf_field() ?>
        <div class="form-group">
            <label>تصویر یا فایل PDF رسید پرداخت</label>
            <div class="dropzone" id="dropzone">
                <div>📎 فایل را بکشید و رها کنید یا کلیک کنید</div>
                <div class="hint" id="file-name-label">JPG، PNG، WEBP یا PDF — حداکثر ۵ مگابایت</div>
                <img id="preview-img" alt="پیش‌نمایش">
            </div>
            <input type="file" id="receipt-input" name="receipt" accept=".jpg,.jpeg,.png,.webp,.pdf" hidden required>
        </div>

        <div class="form-group">
            <label for="captcha">حاصل جمع <?= $a ?> + <?= $b ?> چند می‌شود؟</label>
            <input type="text" inputmode="numeric" id="captcha" name="captcha" required>
        </div>

        <button type="submit" class="btn btn-primary btn-block" id="submit-btn">
            ارسال رسید برای بررسی <span class="spinner"></span>
        </button>
    </form>
</div>

<script>
    lockSubmit(document.getElementById('upload-form'), document.getElementById('submit-btn'));
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>
