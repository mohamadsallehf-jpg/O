<?php
require_once __DIR__ . '/config.php';

$token = clean_str($_GET['token'] ?? '');
$pageTitle = 'ثبت شد | ' . get_setting($pdo, 'site_title');

$req = null;
if ($token !== '') {
    $stmt = $pdo->prepare("SELECT * FROM requests WHERE public_token = :t");
    $stmt->execute([':t' => $token]);
    $req = $stmt->fetch(PDO::FETCH_ASSOC);
}

require __DIR__ . '/includes/header.php';
?>

<div class="card card-glow text-center">
    <?php if ($req): ?>
        <h2>✅ درخواست شما ثبت شد</h2>
        <p class="hint mb-2">نتیجه بررسی به ایمیل شما ارسال خواهد شد.</p>
        <div class="alert alert-warning">کد پیگیری: <b><?= h($req['public_token']) ?></b></div>
        <p class="hint">می‌توانید بعداً با این کد، وضعیت درخواست خود را
            <a href="status.php?token=<?= h($req['public_token']) ?>">بررسی</a> کنید.</p>
        <a href="index.php" class="btn btn-outline btn-block mt-2">ثبت درخواست جدید</a>
    <?php else: ?>
        <h2>درخواست یافت نشد</h2>
        <a href="index.php" class="btn btn-primary btn-block mt-2">بازگشت به صفحه اصلی</a>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
