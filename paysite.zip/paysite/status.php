<?php
require_once __DIR__ . '/config.php';

$pageTitle = 'پیگیری وضعیت | ' . get_setting($pdo, 'site_title');
$token = clean_str($_GET['token'] ?? $_POST['token'] ?? '');
$req = null; $error = '';

if ($token !== '') {
    if (!rate_limit_check($pdo, 'status_check', 20, 60)) {
        $error = 'تعداد درخواست‌های شما زیاد است. کمی بعد دوباره تلاش کنید.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM requests WHERE public_token = :t");
        $stmt->execute([':t' => $token]);
        $req = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$req) $error = 'کد پیگیری یافت نشد.';
    }
}

require __DIR__ . '/includes/header.php';
?>

<div class="card card-glow">
    <h2 class="text-center mb-2">پیگیری وضعیت درخواست</h2>
    <form method="get" class="mb-2">
        <div class="form-group">
            <label for="token">کد پیگیری</label>
            <input type="text" id="token" name="token" value="<?= h($token) ?>" required>
        </div>
        <button type="submit" class="btn btn-primary btn-block">بررسی وضعیت</button>
    </form>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= h($error) ?></div>
    <?php endif; ?>

    <?php if ($req): ?>
        <div class="alert <?= $req['status'] === 'approved' ? 'alert-success' : ($req['status'] === 'rejected' ? 'alert-danger' : 'alert-warning') ?>">
            وضعیت: <b><?= status_label($req['status']) ?></b>
        </div>
        <p>مبلغ: <b><?= toman($req['amount']) ?></b></p>
        <p>تاریخ ثبت: <?= h($req['created_at']) ?></p>
        <?php if ($req['admin_note']): ?>
            <p>توضیح ادمین: <?= h($req['admin_note']) ?></p>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
