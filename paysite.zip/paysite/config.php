<?php
/**
 * config.php
 * تنظیمات اصلی سایت — اتصال دیتابیس، سشن امن، ثابت‌ها
 */

// ---------- تنظیمات پایه ----------
error_reporting(E_ALL);
ini_set('display_errors', '0'); // در حالت production خطاها نمایش داده نشود
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/data/error.log');

define('BASE_PATH', __DIR__);
define('DATA_PATH', __DIR__ . '/data');
define('UPLOAD_PATH', __DIR__ . '/uploads');
define('DB_FILE', DATA_PATH . '/database.sqlite');

// حداکثر حجم فایل آپلودی (بایت) - ۵ مگابایت
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024);
// فرمت‌های مجاز رسید
define('ALLOWED_MIME', ['image/jpeg', 'image/png', 'image/webp', 'application/pdf']);
define('ALLOWED_EXT', ['jpg', 'jpeg', 'png', 'webp', 'pdf']);

// ---------- تنظیم سشن امن ----------
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_strict_mode', '1');
    ini_set('session.cookie_samesite', 'Lax');
    if (!empty($_SERVER['HTTPS'])) {
        ini_set('session.cookie_secure', '1');
    }
    session_start();
}

// ---------- هدرهای امنیتی ----------
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: default-src 'self'; script-src 'self' https://cdn.jsdelivr.net 'unsafe-inline'; style-src 'self' https://cdn.jsdelivr.net https://fonts.googleapis.com 'unsafe-inline'; font-src https://fonts.gstatic.com; img-src 'self' data:;");

// ---------- اتصال دیتابیس ----------
try {
    $pdo = new PDO('sqlite:' . DB_FILE);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec('PRAGMA foreign_keys = ON;');
} catch (Exception $e) {
    error_log('DB Connection Error: ' . $e->getMessage());
    die('خطا در اتصال به پایگاه داده. لطفاً بعداً تلاش کنید.');
}

require_once __DIR__ . '/includes/functions.php';

// ایجاد جداول در صورت نبود (اولین اجرا)
init_database($pdo);
