<?php
/** @var PDO $pdo */
$me = current_admin();
$siteTitle = get_setting($pdo, 'site_title');
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= h($pageTitle ?? 'پنل مدیریت') ?></title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="admin-layout">
    <aside class="sidebar">
        <div class="brand mb-2"><span class="dot"></span> پنل مدیریت</div>
        <a href="dashboard.php" class="<?= $currentPage === 'dashboard.php' ? 'active' : '' ?>">📋 درخواست‌ها</a>
        <a href="stats.php" class="<?= $currentPage === 'stats.php' ? 'active' : '' ?>">📊 آمار</a>
        <?php if ($me['role'] === 'owner'): ?>
            <a href="settings.php" class="<?= $currentPage === 'settings.php' ? 'active' : '' ?>">⚙️ تنظیمات</a>
            <a href="admins.php" class="<?= $currentPage === 'admins.php' ? 'active' : '' ?>">👥 مدیریت ادمین‌ها</a>
            <a href="activity_log.php" class="<?= $currentPage === 'activity_log.php' ? 'active' : '' ?>">🕓 گزارش فعالیت</a>
        <?php endif; ?>
        <a href="logout.php" style="color:var(--danger)">🚪 خروج (<?= h($me['username']) ?>)</a>
        <button id="theme-toggle" class="theme-toggle mt-2">🌙</button>
    </aside>
    <main class="admin-main fade-in">
