<?php
require_once __DIR__ . '/../config.php';
require_owner();

$pageTitle = 'گزارش فعالیت | پنل مدیریت';
$logs = $pdo->query("SELECT * FROM activity_log ORDER BY id DESC LIMIT 200")->fetchAll(PDO::FETCH_ASSOC);

require __DIR__ . '/includes/admin_header.php';
?>

<h2 class="mb-2">گزارش فعالیت‌ها (۲۰۰ مورد آخر)</h2>

<div class="table-wrap">
<table>
<thead><tr><th>#</th><th>کاربر</th><th>عملیات</th><th>جزئیات</th><th>IP</th><th>تاریخ</th></tr></thead>
<tbody>
<?php foreach ($logs as $l): ?>
    <tr>
        <td>#<?= $l['id'] ?></td>
        <td><?= h($l['admin_username'] ?: 'ناشناس') ?></td>
        <td><?= h($l['action']) ?></td>
        <td><?= h($l['details']) ?></td>
        <td><?= h($l['ip_address']) ?></td>
        <td><?= h(substr($l['created_at'], 0, 19)) ?></td>
    </tr>
<?php endforeach; ?>
</tbody>
</table>
</div>

<?php require __DIR__ . '/includes/admin_footer.php'; ?>
