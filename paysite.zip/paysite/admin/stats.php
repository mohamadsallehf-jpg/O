<?php
require_once __DIR__ . '/../config.php';
require_admin();

$pageTitle = 'آمار | پنل مدیریت';

$totalRequests = (int) $pdo->query("SELECT COUNT(*) FROM requests")->fetchColumn();
$totalApproved = (int) $pdo->query("SELECT COUNT(*) FROM requests WHERE status='approved'")->fetchColumn();
$totalRejected = (int) $pdo->query("SELECT COUNT(*) FROM requests WHERE status='rejected'")->fetchColumn();
$totalAmountApproved = (int) $pdo->query("SELECT COALESCE(SUM(amount),0) FROM requests WHERE status='approved'")->fetchColumn();

// آمار ۱۴ روز اخیر
$daily = $pdo->query("
    SELECT substr(created_at,1,10) d, COUNT(*) c
    FROM requests
    WHERE created_at >= date('now','-14 day')
    GROUP BY d ORDER BY d
")->fetchAll(PDO::FETCH_KEY_PAIR);

require __DIR__ . '/includes/admin_header.php';
?>

<h2 class="mb-2">آمار کلی</h2>

<div class="stats-grid">
    <div class="stat-card"><div class="num"><?= $totalRequests ?></div><div class="lbl">کل درخواست‌ها</div></div>
    <div class="stat-card"><div class="num"><?= $totalApproved ?></div><div class="lbl">تایید شده</div></div>
    <div class="stat-card"><div class="num"><?= $totalRejected ?></div><div class="lbl">رد شده</div></div>
    <div class="stat-card"><div class="num"><?= toman($totalAmountApproved) ?></div><div class="lbl">مجموع مبالغ تایید شده</div></div>
</div>

<div class="card">
    <h3 class="mb-2">روند ۱۴ روز اخیر</h3>
    <canvas id="chart" height="90"></canvas>
</div>

<script>
    const labels = <?= json_encode(array_keys($daily), JSON_UNESCAPED_UNICODE) ?>;
    const data = <?= json_encode(array_values($daily)) ?>;
</script>
<script>
// نمودار ساده بدون نیاز به کتابخانه خارجی (canvas خام)
(function () {
    const canvas = document.getElementById('chart');
    const ctx = canvas.getContext('2d');
    const w = canvas.width = canvas.clientWidth;
    const h = canvas.height;
    const max = Math.max(1, ...data);
    const barW = w / (data.length || 1);
    ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--primary') || '#6366f1';
    data.forEach((v, i) => {
        const barH = (v / max) * (h - 30);
        ctx.fillRect(i * barW + 4, h - barH - 20, barW - 8, barH);
        ctx.fillStyle = '#9ca3af';
        ctx.font = '10px Tahoma';
        ctx.textAlign = 'center';
        ctx.fillText(labels[i] ? labels[i].slice(5) : '', i * barW + barW / 2, h - 5);
        ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--primary') || '#6366f1';
    });
})();
</script>

<?php require __DIR__ . '/includes/admin_footer.php'; ?>
