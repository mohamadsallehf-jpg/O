<?php
require_once __DIR__ . '/../config.php';
require_owner();

$pageTitle = 'مدیریت ادمین‌ها | پنل مدیریت';
$me = current_admin();
$notice = ''; $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        $error = 'خطای امنیتی. دوباره تلاش کنید.';
    } else {
        $op = $_POST['op'] ?? '';

        if ($op === 'create') {
            $username = clean_str($_POST['username'] ?? '');
            $email = clean_str($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $role = ($_POST['role'] ?? 'admin') === 'owner' ? 'owner' : 'admin';

            if (mb_strlen($username) < 3 || mb_strlen($password) < 8) {
                $error = 'نام کاربری حداقل ۳ و رمز عبور حداقل ۸ کاراکتر باشد.';
            } else {
                try {
                    $stmt = $pdo->prepare("INSERT INTO admins (username, password_hash, email, role, created_at) VALUES (:u,:p,:e,:r,:c)");
                    $stmt->execute([
                        ':u' => $username, ':p' => password_hash($password, PASSWORD_DEFAULT),
                        ':e' => $email, ':r' => $role, ':c' => date('c'),
                    ]);
                    log_activity($pdo, $me['id'], $me['username'], 'create_admin', "ایجاد ادمین جدید: $username ($role)");
                    $notice = 'ادمین جدید با موفقیت ایجاد شد.';
                } catch (Exception $e) {
                    $error = 'این نام کاربری قبلاً استفاده شده است.';
                }
            }
        } elseif ($op === 'toggle') {
            $id = (int) ($_POST['id'] ?? 0);
            if ($id !== $me['id']) {
                $pdo->prepare("UPDATE admins SET is_active = 1 - is_active WHERE id = :id")->execute([':id' => $id]);
                log_activity($pdo, $me['id'], $me['username'], 'toggle_admin', "تغییر وضعیت ادمین #$id");
                $notice = 'وضعیت ادمین به‌روزرسانی شد.';
            } else {
                $error = 'نمی‌توانید حساب خودتان را غیرفعال کنید.';
            }
        } elseif ($op === 'delete') {
            $id = (int) ($_POST['id'] ?? 0);
            if ($id !== $me['id']) {
                $pdo->prepare("DELETE FROM admins WHERE id = :id")->execute([':id' => $id]);
                log_activity($pdo, $me['id'], $me['username'], 'delete_admin', "حذف ادمین #$id");
                $notice = 'ادمین حذف شد.';
            } else {
                $error = 'نمی‌توانید حساب خودتان را حذف کنید.';
            }
        } elseif ($op === 'reset_password') {
            $id = (int) ($_POST['id'] ?? 0);
            $newPass = $_POST['new_password'] ?? '';
            if (mb_strlen($newPass) < 8) {
                $error = 'رمز عبور جدید باید حداقل ۸ کاراکتر باشد.';
            } else {
                $pdo->prepare("UPDATE admins SET password_hash = :p WHERE id = :id")
                    ->execute([':p' => password_hash($newPass, PASSWORD_DEFAULT), ':id' => $id]);
                log_activity($pdo, $me['id'], $me['username'], 'reset_password', "بازنشانی رمز ادمین #$id");
                $notice = 'رمز عبور با موفقیت تغییر کرد.';
            }
        }
    }
}

$admins = $pdo->query("SELECT * FROM admins ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

require __DIR__ . '/includes/admin_header.php';
?>

<h2 class="mb-2">مدیریت ادمین‌ها</h2>
<?php if ($notice): ?><div class="alert alert-success"><?= h($notice) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endif; ?>

<div class="card mb-2">
    <h3 class="mb-2">افزودن ادمین جدید</h3>
    <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="op" value="create">
        <div class="form-group"><label>نام کاربری</label><input type="text" name="username" required></div>
        <div class="form-group"><label>ایمیل (برای دریافت اعلان رسید جدید)</label><input type="email" name="email"></div>
        <div class="form-group"><label>رمز عبور</label><input type="password" name="password" required minlength="8"></div>
        <div class="form-group">
            <label>نقش</label>
            <select name="role">
                <option value="admin">ادمین (بررسی رسیدها)</option>
                <option value="owner">مالک (دسترسی کامل)</option>
            </select>
        </div>
        <button class="btn btn-primary">ایجاد ادمین</button>
    </form>
</div>

<div class="table-wrap">
<table>
<thead><tr><th>#</th><th>نام کاربری</th><th>ایمیل</th><th>نقش</th><th>وضعیت</th><th>آخرین ورود</th><th>عملیات</th></tr></thead>
<tbody>
<?php foreach ($admins as $a): ?>
    <tr>
        <td>#<?= $a['id'] ?></td>
        <td><?= h($a['username']) ?></td>
        <td><?= h($a['email'] ?: '—') ?></td>
        <td><?= $a['role'] === 'owner' ? 'مالک' : 'ادمین' ?></td>
        <td><span class="badge <?= $a['is_active'] ? 'badge-success' : 'badge-danger' ?>"><?= $a['is_active'] ? 'فعال' : 'غیرفعال' ?></span></td>
        <td><?= h(substr($a['last_login'] ?? '—', 0, 16)) ?></td>
        <td style="display:flex;gap:6px;flex-wrap:wrap;">
            <form method="post" style="display:inline">
                <?= csrf_field() ?>
                <input type="hidden" name="op" value="toggle">
                <input type="hidden" name="id" value="<?= $a['id'] ?>">
                <button class="btn btn-sm btn-outline" <?= $a['id'] === $me['id'] ? 'disabled' : '' ?>><?= $a['is_active'] ? 'غیرفعال‌سازی' : 'فعال‌سازی' ?></button>
            </form>
            <button class="btn btn-sm btn-outline" onclick="openReset(<?= $a['id'] ?>)">تغییر رمز</button>
            <form method="post" style="display:inline" onsubmit="return confirm('آیا از حذف این ادمین مطمئن هستید؟')">
                <?= csrf_field() ?>
                <input type="hidden" name="op" value="delete">
                <input type="hidden" name="id" value="<?= $a['id'] ?>">
                <button class="btn btn-sm btn-danger" <?= $a['id'] === $me['id'] ? 'disabled' : '' ?>>حذف</button>
            </form>
        </td>
    </tr>
<?php endforeach; ?>
</tbody>
</table>
</div>

<div id="reset-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);align-items:center;justify-content:center;z-index:100;">
    <div class="card" style="max-width:380px;width:90%;">
        <h3 class="mb-2">تغییر رمز عبور</h3>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="op" value="reset_password">
            <input type="hidden" name="id" id="reset-id">
            <div class="form-group"><label>رمز عبور جدید</label><input type="password" name="new_password" minlength="8" required></div>
            <button class="btn btn-primary btn-block">ثبت</button>
            <button type="button" class="btn btn-outline btn-block mt-2" onclick="document.getElementById('reset-modal').style.display='none'">انصراف</button>
        </form>
    </div>
</div>
<script>
function openReset(id) {
    document.getElementById('reset-id').value = id;
    document.getElementById('reset-modal').style.display = 'flex';
}
</script>

<?php require __DIR__ . '/includes/admin_footer.php'; ?>
