<?php
require_once __DIR__ . '/../config.php';
require_owner();

$pageTitle = 'تنظیمات | پنل مدیریت';
$me = current_admin();
$notice = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        $notice = 'خطای امنیتی. دوباره تلاش کنید.';
    } else {
        $fields = [
            'site_title', 'card_number', 'card_holder', 'bank_name',
            'min_amount', 'max_amount', 'primary_color', 'support_text',
            'smtp_enabled', 'smtp_host', 'smtp_port', 'smtp_user', 'smtp_pass',
            'smtp_from', 'smtp_from_name',
        ];
        foreach ($fields as $f) {
            if (isset($_POST[$f])) {
                set_setting($pdo, $f, clean_str($_POST[$f]));
            }
        }
        // چک‌باکس smtp_enabled در صورت عدم ارسال یعنی خاموش
        set_setting($pdo, 'smtp_enabled', isset($_POST['smtp_enabled']) ? '1' : '0');

        log_activity($pdo, $me['id'], $me['username'], 'update_settings', 'به‌روزرسانی تنظیمات سامانه');
        $notice = 'تنظیمات با موفقیت ذخیره شد.';
    }
}

$s = get_all_settings($pdo);

require __DIR__ . '/includes/admin_header.php';
?>

<h2 class="mb-2">تنظیمات سامانه</h2>

<?php if ($notice): ?><div class="alert alert-success"><?= h($notice) ?></div><?php endif; ?>

<form method="post">
<?= csrf_field() ?>

<div class="card mb-2">
    <h3 class="mb-2">اطلاعات عمومی</h3>
    <div class="form-group"><label>عنوان سایت</label><input type="text" name="site_title" value="<?= h($s['site_title']) ?>"></div>
    <div class="form-group"><label>متن پشتیبانی</label><textarea name="support_text" rows="2"><?= h($s['support_text']) ?></textarea></div>
    <div class="form-group"><label>رنگ اصلی (Hex)</label><input type="text" name="primary_color" value="<?= h($s['primary_color']) ?>"></div>
</div>

<div class="card mb-2">
    <h3 class="mb-2">اطلاعات کارت بانکی</h3>
    <div class="form-group"><label>شماره کارت</label><input type="text" name="card_number" value="<?= h($s['card_number']) ?>"></div>
    <div class="form-group"><label>نام صاحب حساب</label><input type="text" name="card_holder" value="<?= h($s['card_holder']) ?>"></div>
    <div class="form-group"><label>نام بانک</label><input type="text" name="bank_name" value="<?= h($s['bank_name']) ?>"></div>
</div>

<div class="card mb-2">
    <h3 class="mb-2">محدوده مبلغ مجاز (تومان)</h3>
    <div class="form-group"><label>حداقل مبلغ</label><input type="text" name="min_amount" value="<?= h($s['min_amount']) ?>"></div>
    <div class="form-group"><label>حداکثر مبلغ</label><input type="text" name="max_amount" value="<?= h($s['max_amount']) ?>"></div>
</div>

<div class="card mb-2">
    <h3 class="mb-2">تنظیمات ایمیل (SMTP)</h3>
    <p class="hint mb-2">در صورت غیرفعال بودن، از تابع پیش‌فرض mail سرور استفاده می‌شود که ممکن است در برخی میزبان‌ها به اسپم بیفتد. برای اطمینان از تحویل، SMTP را فعال کنید.</p>
    <div class="form-group">
        <label><input type="checkbox" name="smtp_enabled" <?= $s['smtp_enabled'] === '1' ? 'checked' : '' ?>> فعال‌سازی ارسال از طریق SMTP</label>
    </div>
    <div class="form-group"><label>هاست SMTP</label><input type="text" name="smtp_host" value="<?= h($s['smtp_host']) ?>" placeholder="smtp.gmail.com"></div>
    <div class="form-group"><label>پورت</label><input type="text" name="smtp_port" value="<?= h($s['smtp_port']) ?>"></div>
    <div class="form-group"><label>نام کاربری</label><input type="text" name="smtp_user" value="<?= h($s['smtp_user']) ?>"></div>
    <div class="form-group"><label>رمز عبور</label><input type="password" name="smtp_pass" value="<?= h($s['smtp_pass']) ?>"></div>
    <div class="form-group"><label>ایمیل فرستنده</label><input type="text" name="smtp_from" value="<?= h($s['smtp_from']) ?>"></div>
    <div class="form-group"><label>نام فرستنده</label><input type="text" name="smtp_from_name" value="<?= h($s['smtp_from_name']) ?>"></div>
</div>

<button type="submit" class="btn btn-primary btn-block">ذخیره تنظیمات</button>
</form>

<?php require __DIR__ . '/includes/admin_footer.php'; ?>
