<?php
require_once __DIR__ . '/../config.php';

if (current_admin()) {
    redirect('dashboard.php');
}

$pageTitle = 'ورود ادمین';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        $error = 'نشست منقضی شده. صفحه را رفرش کنید.';
    } elseif (!rate_limit_check($pdo, 'admin_login', 6, 300)) {
        $error = 'تلاش‌های ورود بیش از حد مجاز است. ۵ دقیقه دیگر تلاش کنید.';
    } else {
        $username = clean_str($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = :u AND is_active = 1");
        $stmt->execute([':u' => $username]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($admin && password_verify($password, $admin['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['admin'] = [
                'id' => $admin['id'],
                'username' => $admin['username'],
                'role' => $admin['role'],
            ];
            $pdo->prepare("UPDATE admins SET last_login = :t WHERE id = :id")
                ->execute([':t' => date('c'), ':id' => $admin['id']]);
            log_activity($pdo, $admin['id'], $admin['username'], 'login', 'ورود موفق به پنل');
            redirect('dashboard.php');
        } else {
            log_activity($pdo, null, $username, 'login_failed', 'تلاش ناموفق برای ورود');
            $error = 'نام کاربری یا رمز عبور اشتباه است.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= h($pageTitle) ?></title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="container-narrow" style="padding-top:60px;">
    <div class="text-center mb-2">
        <div class="navbar" style="justify-content:center;">
            <div class="brand"><span class="dot"></span> پنل مدیریت</div>
        </div>
    </div>
    <div class="card card-glow fade-in">
        <h2 class="text-center mb-2">ورود به پنل مدیریت</h2>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= h($error) ?></div>
        <?php endif; ?>
        <form method="post">
            <?= csrf_field() ?>
            <div class="form-group">
                <label for="username">نام کاربری</label>
                <input type="text" id="username" name="username" required autofocus>
            </div>
            <div class="form-group">
                <label for="password">رمز عبور</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">ورود</button>
        </form>
    </div>
</div>
<script src="../assets/js/app.js"></script>
</body>
</html>
