<?php
require_once __DIR__ . '/../config.php';
require_admin();

$id = (int) ($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT receipt_path FROM requests WHERE id = :id");
$stmt->execute([':id' => $id]);
$path = $stmt->fetchColumn();

if (!$path) {
    http_response_code(404);
    die('فایل یافت نشد.');
}

$fullPath = UPLOAD_PATH . '/' . basename($path); // basename برای جلوگیری از path traversal
if (!is_file($fullPath)) {
    http_response_code(404);
    die('فایل یافت نشد.');
}

log_activity($pdo, current_admin()['id'], current_admin()['username'], 'view_receipt', "درخواست #$id");

$mime = mime_content_type($fullPath) ?: 'application/octet-stream';
header('Content-Type: ' . $mime);
header('X-Content-Type-Options: nosniff');
header('Content-Disposition: inline; filename="receipt-' . $id . '.' . pathinfo($fullPath, PATHINFO_EXTENSION) . '"');
header('Content-Length: ' . filesize($fullPath));
readfile($fullPath);
