<?php
require_once __DIR__ . '/../config.php';
redirect(current_admin() ? 'dashboard.php' : 'login.php');
