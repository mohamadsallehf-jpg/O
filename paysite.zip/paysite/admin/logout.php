<?php
require_once __DIR__ . '/../config.php';
if (current_admin()) {
    log_activity($pdo, current_admin()['id'], current_admin()['username'], 'logout', 'خروج از پنل');
}
$_SESSION = [];
session_destroy();
redirect('login.php');
