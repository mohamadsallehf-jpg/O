<?php
require_once __DIR__ . '/../config.php';
require_admin();

$pageTitle = 'درخواست‌ها | پنل مدیریت';
$me = current_admin();
$notice = '';

// ---------- اقدام تایید/رد ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!csrf_verify()) {
        $notice = 'خطای امنیتی: نشست منقضی شده.';
    } else {
        $id = (int) ($_POST['id'] ?? 0);
        $action = $_POST['action'];
        $note = clean_str($_POST['admin_note'] ?? '');

        $stmt = $pdo->prepare("SELECT * FROM requests WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $req = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($req && in_array($action, ['approve', 'reject'], true) && $req['status'] === 'pending') {
            $newStatus = $action === 'approve' ? 'approved' : 'rejected';
            $pdo->prepare("UPDATE requests SET status=:s, admin_note=:n, reviewed_by=:r, updated_at=:u WHERE id=:id")
                ->execute([':s' => $newStatus, ':n' => $note, ':r' => $me['id'], ':u' => date('c'), ':id' => $id]);

            log_activity($pdo, $me['id'], $me['username'], "request_$newStatus", "درخواست #$id ($req[email])");

            // ارسال ایمیل خودکار نتیجه به کاربر
            $subject = $newStatus === 'approved' ? 'پرداخت شما تایید شد ✅' : 'پرداخت شما رد شد ❌';
            $bodyStatus = $newStatus === 'approved'
                ? 'پرداخت شما با موفقیت تایید شد. متشکریم!'
                : 'متاسفانه پرداخت شما رد شد.' . ($note ? " دلیل: " . h($note) : '');
            send_email($pdo, $req['email'], $subject,
                "<div style='font-family:Tahoma;direction:rtl'>
                <p>سلام " . h($req['full_name']) . "،</p>
                <p>$bodyStatus</p>
                <p>مبلغ: " . toman($req['amount']) . "</p>
                <p>کد پیگیری: {$req['public_token']}</p>
                </div>");

            $notice = "درخواست #$id با موفقیت " . ($action === 'approve' ? 'تایید' : 'رد') . " شد و ایمیل ارسال گردید.";
        }
    }
}

// ---------- فیلتر و لیست ----------
$filter = $_GET['status'] ?? 'pending';
$allowedFilters = ['pending', 'approved', 'rejected', 'all'];
if (!in_array($filter, $allowedFilters, true)) $filter = 'pending';

$search = clean_str($_GET['q'] ?? '');

$sql = "SELECT * FROM requests WHERE 1=1";
$params = [];
if ($filter !== 'all') {
    $sql .= " AND status = :status";
    $params[':status'] = $filter;
}
if ($search !== '') {
    $sql .= " AND (email LIKE :q OR full_name LIKE :q OR public_token LIKE :q)";
    $params[':q'] = "%$search%";
}
$sql .= " ORDER BY created_at DESC LIMIT 100";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

$counts = $pdo->query("SELECT status, COUNT(*) c FROM requests GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR);

require __DIR__ . '/includes/admin_header.php';
?>

<div class="stats-grid">
    <div class="stat-card"><div class="num"><?= $counts['pending'] ?? 0 ?></div><div class="lbl">در انتظار بررسی</div></div>
    <div class="stat-card"><div class="num"><?= $counts['approved'] ?? 0 ?></div><div class="lbl">تایید شده</div></div>
    <div class="stat-card"><div class="num"><?= $counts['rejected'] ?? 0 ?></div><div class="lbl">رد شده</div></div>
</div>

<?php if ($notice): ?>
    <div class="alert alert-success"><?= h($notice) ?></div>
<?php endif; ?>

<div class="card mb-2">
    <form method="get" style="display:flex;gap:10px;flex-wrap:wrap;align-items:end;">
        <div class="form-group" style="margin-bottom:0;flex:1;min-width:160px;">
            <label>وضعیت</label>
            <select name="status" onchange="this.form.submit()">
                <option value="pending" <?= $filter === 'pending' ? 'selected' : '' ?>>در انتظار بررسی</option>
                <option value="approved" <?= $filter === 'approved' ? 'selected' : '' ?>>تایید شده</option>
                <option value="rejected" <?= $filter === 'rejected' ? 'selected' : '' ?>>رد شده</option>
                <option value="all" <?= $filter === 'all' ? 'selected' : '' ?>>همه</option>
            </select>
        </div>
        <div class="form-group" style="margin-bottom:0;flex:2;min-width:200px;">
            <label>جستجو (نام / ایمیل / کد پیگیری)</label>
            <input type="text" name="q" value="<?= h($search) ?>">
        </div>
        <button class="btn btn-primary">جستجو</button>
    </form>
</div>

<div class="table-wrap">
<table>
<thead>
<tr>
    <th>#</th><th>نام</th><th>ایمیل</th><th>مبلغ</th><th>رسید</th><th>وضعیت</th><th>تاریخ</th><th>عملیات</th>
</tr>
</thead>
<tbody>
<?php foreach ($requests as $r): ?>
    <tr>
        <td>#<?= $r['id'] ?></td>
        <td><?= h($r['full_name']) ?></td>
        <td><?= h($r['email']) ?></td>
        <td><?= toman($r['amount']) ?></td>
        <td><a href="view_receipt.php?id=<?= $r['id'] ?>" target="_blank" class="btn btn-sm btn-outline">مشاهده</a></td>
        <td><span class="badge <?= status_badge_class($r['status']) ?>"><?= status_label($r['status']) ?></span></td>
        <td><?= h(substr($r['created_at'], 0, 16)) ?></td>
        <td>
            <?php if ($r['status'] === 'pending'): ?>
                <button class="btn btn-sm btn-success" onclick="openReview(<?= $r['id'] ?>, 'approve')">تایید</button>
                <button class="btn btn-sm btn-danger" onclick="openReview(<?= $r['id'] ?>, 'reject')">رد</button>
            <?php else: ?>
                <span class="hint"><?= h($r['admin_note'] ?: '—') ?></span>
            <?php endif; ?>
        </td>
    </tr>
<?php endforeach; ?>
<?php if (!$requests): ?>
    <tr><td colspan="8" class="text-center">موردی یافت نشد.</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>

<!-- مودال بررسی -->
<div id="review-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);align-items:center;justify-content:center;z-index:100;">
    <div class="card" style="max-width:420px;width:90%;">
        <h3 id="modal-title" class="mb-2"></h3>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="id" id="modal-id">
            <input type="hidden" name="action" id="modal-action">
            <div class="form-group">
                <label>یادداشت / دلیل (اختیاری - در ایمیل کاربر نمایش داده می‌شود)</label>
                <textarea name="admin_note" rows="3"></textarea>
            </div>
            <button type="submit" class="btn btn-primary btn-block">ثبت نهایی</button>
            <button type="button" class="btn btn-outline btn-block mt-2" onclick="closeReview()">انصراف</button>
        </form>
    </div>
</div>

<script>
function openReview(id, action) {
    document.getElementById('modal-id').value = id;
    document.getElementById('modal-action').value = action;
    document.getElementById('modal-title').textContent = action === 'approve' ? 'تایید درخواست #' + id : 'رد درخواست #' + id;
    document.getElementById('review-modal').style.display = 'flex';
}
function closeReview() {
    document.getElementById('review-modal').style.display = 'none';
}
</script>

<?php require __DIR__ . '/includes/admin_footer.php'; ?>
