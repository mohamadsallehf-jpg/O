<?php
/** @var PDO $pdo */
$siteTitle = get_setting($pdo, 'site_title', 'سامانه پرداخت');
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= h($pageTitle ?? $siteTitle) ?></title>
<link rel="stylesheet" href="<?= isset($assetPrefix) ? $assetPrefix : '' ?>assets/css/style.css">
</head>
<body>
<div class="container">
    <div class="navbar">
        <div class="brand"><span class="dot"></span> <?= h($siteTitle) ?></div>
        <button id="theme-toggle" class="theme-toggle" title="تغییر پوسته">🌙</button>
    </div>
</div>
<div class="container-narrow fade-in">
