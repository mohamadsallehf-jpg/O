<?php
/**
 * functions.php
 * توابع کمکی: امنیت، دیتابیس، ایمیل، اعتبارسنجی
 */

/* ==================== دیتابیس ==================== */
function init_database(PDO $pdo) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS admins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        email TEXT,
        role TEXT NOT NULL DEFAULT 'admin', -- owner | admin
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        last_login TEXT
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        public_token TEXT UNIQUE NOT NULL,
        full_name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT,
        amount INTEGER NOT NULL,
        card_number_shown TEXT,
        receipt_path TEXT,
        receipt_original_name TEXT,
        status TEXT NOT NULL DEFAULT 'pending', -- pending | approved | rejected
        admin_note TEXT,
        reviewed_by INTEGER,
        ip_address TEXT,
        user_agent TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS activity_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        admin_id INTEGER,
        admin_username TEXT,
        action TEXT NOT NULL,
        details TEXT,
        ip_address TEXT,
        created_at TEXT NOT NULL
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS rate_limits (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        bucket TEXT NOT NULL,
        ip_address TEXT NOT NULL,
        created_at INTEGER NOT NULL
    )");

    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_requests_status ON requests(status)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_rate_bucket_ip ON rate_limits(bucket, ip_address)");

    // مقادیر پیش‌فرض تنظیمات
    $defaults = [
        'site_title'      => 'سامانه پرداخت کارت به کارت',
        'card_number'     => '0000-0000-0000-0000',
        'card_holder'     => 'نام صاحب حساب',
        'bank_name'       => 'نام بانک',
        'min_amount'      => '10000',
        'max_amount'      => '500000000',
        'primary_color'   => '#6366f1',
        'support_text'    => 'در صورت بروز مشکل با پشتیبانی در تماس باشید.',
        'smtp_enabled'    => '0',
        'smtp_host'       => '',
        'smtp_port'       => '587',
        'smtp_user'       => '',
        'smtp_pass'       => '',
        'smtp_from'       => 'no-reply@example.com',
        'smtp_from_name'  => 'سامانه پرداخت',
    ];
    $stmt = $pdo->prepare("INSERT OR IGNORE INTO settings (key, value) VALUES (:k, :v)");
    foreach ($defaults as $k => $v) {
        $stmt->execute([':k' => $k, ':v' => $v]);
    }

    // ایجاد مالک پیش‌فرض در صورت نبودن هیچ ادمینی
    $count = $pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn();
    if ($count == 0) {
        $defaultUser = 'owner';
        $defaultPass = bin2hex(random_bytes(4)); // رمز تصادفی اولیه
        $hash = password_hash($defaultPass, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO admins (username, password_hash, role, created_at) VALUES (:u, :p, 'owner', :c)");
        $stmt->execute([':u' => $defaultUser, ':p' => $hash, ':c' => date('c')]);
        file_put_contents(DATA_PATH . '/FIRST_LOGIN_CREDENTIALS.txt',
            "نام کاربری: $defaultUser\nرمز عبور: $defaultPass\n\nاین فایل را پس از ورود اول حذف کنید!");
    }
}

function get_setting(PDO $pdo, string $key, $default = '') {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        foreach ($pdo->query("SELECT key, value FROM settings") as $row) {
            $cache[$row['key']] = $row['value'];
        }
    }
    return $cache[$key] ?? $default;
}

function get_all_settings(PDO $pdo): array {
    $out = [];
    foreach ($pdo->query("SELECT key, value FROM settings") as $row) {
        $out[$row['key']] = $row['value'];
    }
    return $out;
}

function set_setting(PDO $pdo, string $key, string $value) {
    $stmt = $pdo->prepare("INSERT INTO settings (key, value) VALUES (:k, :v)
                            ON CONFLICT(key) DO UPDATE SET value = :v2");
    $stmt->execute([':k' => $key, ':v' => $value, ':v2' => $value]);
}

/* ==================== امنیت: CSRF ==================== */
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_token()) . '">';
}

function csrf_verify(): bool {
    $token = $_POST['csrf_token'] ?? '';
    return !empty($token) && !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/* ==================== امنیت: Rate limiting ==================== */
function client_ip(): string {
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

/**
 * بررسی محدودیت نرخ درخواست. مثال: حداکثر 5 درخواست در 60 ثانیه برای هر IP
 */
function rate_limit_check(PDO $pdo, string $bucket, int $maxAttempts, int $windowSeconds): bool {
    $ip = client_ip();
    $now = time();
    $windowStart = $now - $windowSeconds;

    $pdo->prepare("DELETE FROM rate_limits WHERE bucket = :b AND created_at < :w")
        ->execute([':b' => $bucket, ':w' => $windowStart]);

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM rate_limits WHERE bucket = :b AND ip_address = :ip AND created_at >= :w");
    $stmt->execute([':b' => $bucket, ':ip' => $ip, ':w' => $windowStart]);
    $count = (int) $stmt->fetchColumn();

    if ($count >= $maxAttempts) {
        return false; // محدود شده
    }

    $pdo->prepare("INSERT INTO rate_limits (bucket, ip_address, created_at) VALUES (:b, :ip, :t)")
        ->execute([':b' => $bucket, ':ip' => $ip, ':t' => $now]);

    return true;
}

/* ==================== اعتبارسنجی ورودی ==================== */
function clean_str(?string $s): string {
    return trim(strip_tags($s ?? ''));
}

function is_valid_email(string $email): bool {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function is_valid_amount($amount, PDO $pdo): array {
    $amount = preg_replace('/[^0-9]/', '', (string) $amount);
    if ($amount === '') return [false, 0, 'مبلغ نامعتبر است.'];
    $amount = (int) $amount;
    $min = (int) get_setting($pdo, 'min_amount', 10000);
    $max = (int) get_setting($pdo, 'max_amount', 500000000);
    if ($amount < $min) return [false, $amount, "حداقل مبلغ مجاز " . number_format($min) . " تومان است."];
    if ($amount > $max) return [false, $amount, "حداکثر مبلغ مجاز " . number_format($max) . " تومان است."];
    return [true, $amount, ''];
}

/* ==================== آپلود فایل امن ==================== */
function handle_receipt_upload(array $file): array {
    if (!isset($file['error']) || is_array($file['error'])) {
        return [false, '', 'خطا در دریافت فایل.'];
    }
    if ($file['error'] === UPLOAD_ERR_NO_FILE) {
        return [false, '', 'لطفاً تصویر رسید را انتخاب کنید.'];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return [false, '', 'خطا در آپلود فایل.'];
    }
    if ($file['size'] > MAX_UPLOAD_SIZE) {
        return [false, '', 'حجم فایل بیشتر از حد مجاز (۵ مگابایت) است.'];
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime, ALLOWED_MIME, true)) {
        return [false, '', 'فرمت فایل مجاز نیست. فقط JPG، PNG، WEBP یا PDF مجاز است.'];
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ALLOWED_EXT, true)) {
        $map = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'application/pdf' => 'pdf'];
        $ext = $map[$mime] ?? 'bin';
    }

    // نام تصادفی و غیرقابل حدس برای جلوگیری از دسترسی مستقیم/تداخل
    $newName = bin2hex(random_bytes(16)) . '.' . $ext;
    $dest = UPLOAD_PATH . '/' . $newName;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        return [false, '', 'خطا در ذخیره‌سازی فایل.'];
    }
    chmod($dest, 0640);

    return [true, $newName, ''];
}

/* ==================== ثبت لاگ فعالیت ==================== */
function log_activity(PDO $pdo, ?int $adminId, string $adminUsername, string $action, string $details = '') {
    $stmt = $pdo->prepare("INSERT INTO activity_log (admin_id, admin_username, action, details, ip_address, created_at)
                            VALUES (:aid, :au, :ac, :d, :ip, :c)");
    $stmt->execute([
        ':aid' => $adminId, ':au' => $adminUsername, ':ac' => $action,
        ':d' => $details, ':ip' => client_ip(), ':c' => date('c')
    ]);
}

/* ==================== ارسال ایمیل ==================== */
function send_email(PDO $pdo, string $to, string $subject, string $htmlBody): bool {
    $fromName = get_setting($pdo, 'smtp_from_name', 'سامانه پرداخت');
    $fromAddr = get_setting($pdo, 'smtp_from', 'no-reply@example.com');

    if (get_setting($pdo, 'smtp_enabled', '0') === '1') {
        return send_email_smtp($pdo, $to, $subject, $htmlBody);
    }

    // حالت ساده: تابع mail داخلی PHP (نیازمند تنظیم صحیح sendmail/MTA در سرور میزبان)
    $headers  = "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    $headers .= "From: {$fromName} <{$fromAddr}>\r\n";
    $encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';

    try {
        return @mail($to, $encodedSubject, $htmlBody, $headers);
    } catch (Exception $e) {
        error_log('Mail Error: ' . $e->getMessage());
        return false;
    }
}

/**
 * ارسال از طریق SMTP (بدون کتابخانه خارجی - پیاده‌سازی سبک).
 * برای استفاده حرفه‌ای‌تر پیشنهاد می‌شود از PHPMailer استفاده شود.
 */
function send_email_smtp(PDO $pdo, string $to, string $subject, string $htmlBody): bool {
    $host = get_setting($pdo, 'smtp_host');
    $port = (int) get_setting($pdo, 'smtp_port', 587);
    $user = get_setting($pdo, 'smtp_user');
    $pass = get_setting($pdo, 'smtp_pass');
    $fromAddr = get_setting($pdo, 'smtp_from', $user);
    $fromName = get_setting($pdo, 'smtp_from_name', 'سامانه پرداخت');

    try {
        $context = stream_context_create(['ssl' => ['verify_peer' => true, 'verify_peer_name' => true]]);
        $socket = @stream_socket_client(
            "tcp://$host:$port", $errno, $errstr, 15, STREAM_CLIENT_CONNECT, $context
        );
        if (!$socket) { error_log("SMTP connect failed: $errstr"); return false; }

        $read = function () use ($socket) { return fgets($socket, 512); };
        $write = function ($cmd) use ($socket) { fwrite($socket, $cmd . "\r\n"); };

        $read();
        $write("EHLO localhost"); $read();
        $write("STARTTLS"); $read();
        stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
        $write("EHLO localhost"); $read();
        $write("AUTH LOGIN"); $read();
        $write(base64_encode($user)); $read();
        $write(base64_encode($pass)); $read();
        $write("MAIL FROM:<$fromAddr>"); $read();
        $write("RCPT TO:<$to>"); $read();
        $write("DATA"); $read();

        $headers = "From: {$fromName} <{$fromAddr}>\r\nTo: <$to>\r\nSubject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\nMIME-Version: 1.0\r\nContent-Type: text/html; charset=UTF-8\r\n\r\n";
        $write($headers . $htmlBody . "\r\n.");
        $read();
        $write("QUIT");
        fclose($socket);
        return true;
    } catch (Exception $e) {
        error_log('SMTP Error: ' . $e->getMessage());
        return false;
    }
}

/* ==================== احراز هویت ادمین ==================== */
function current_admin(): ?array {
    return $_SESSION['admin'] ?? null;
}

function require_admin() {
    if (!current_admin()) {
        header('Location: login.php');
        exit;
    }
}

function require_owner() {
    require_admin();
    if (current_admin()['role'] !== 'owner') {
        http_response_code(403);
        die('دسترسی غیرمجاز. این بخش فقط برای مالک سامانه است.');
    }
}

/* ==================== سایر ابزارها ==================== */
function redirect(string $url) {
    header("Location: $url");
    exit;
}

function json_response(array $data, int $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function h(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

function toman(int $n): string {
    return number_format($n) . ' تومان';
}

function status_label(string $status): string {
    return match ($status) {
        'approved' => 'تایید شده',
        'rejected' => 'رد شده',
        default => 'در انتظار بررسی',
    };
}

function status_badge_class(string $status): string {
    return match ($status) {
        'approved' => 'badge-success',
        'rejected' => 'badge-danger',
        default => 'badge-warning',
    };
}
