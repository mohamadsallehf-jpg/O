</div>
<div class="footer">
    &copy; <?= date('Y') ?> <?= h($siteTitle ?? '') ?> — تمامی حقوق محفوظ است.
</div>
<script src="<?= isset($assetPrefix) ? $assetPrefix : '' ?>assets/js/app.js"></script>
</body>
</html>
